#include "sha2.h"
#include <string.h>
#include "mbedtls/sha256.h"
#include "mbedtls/sha512.h"

// --- SHA256 ---
void sha256_inc_init(sha256ctx *ctx) {
    mbedtls_sha256_init((mbedtls_sha256_context *)ctx);
    mbedtls_sha256_starts((mbedtls_sha256_context *)ctx, 0); 
}

void sha256_inc_blocks(sha256ctx *ctx, const uint8_t *in, size_t inblocks) {
    mbedtls_sha256_update((mbedtls_sha256_context *)ctx, in, inblocks * 64);
}

void sha256_inc_finalize(uint8_t *out, sha256ctx *ctx, const uint8_t *in, size_t inlen) {
    mbedtls_sha256_update((mbedtls_sha256_context *)ctx, in, inlen);
    mbedtls_sha256_finish((mbedtls_sha256_context *)ctx, out);
    mbedtls_sha256_free((mbedtls_sha256_context *)ctx);
}

void sha256(uint8_t *out, const uint8_t *in, size_t inlen) {
    mbedtls_sha256(in, inlen, out, 0);
}

// --- SHA512 (Rezolvă eroarea sha512 implicit declaration) ---
void sha512(uint8_t *out, const uint8_t *in, size_t inlen) {
    mbedtls_sha512(in, inlen, out, 0); // 0 indică SHA512 (nu 512/224 sau 256)
}

void sha256_inc_ctx_clone(sha256ctx *out, const sha256ctx *in) {
    mbedtls_sha256_clone((mbedtls_sha256_context *)out, (const mbedtls_sha256_context *)in);
}

void sha256_inc_ctx_release(sha256ctx *ctx) {
    mbedtls_sha256_free((mbedtls_sha256_context *)ctx);
}

// Stubs pentru a evita erori de linker pe alte module x8
void sha256_init8x(void *ctx) {}
void sha256_transform8x(void *ctx, const unsigned char *in) {}
void sha256_final8x(void *out, void *ctx) {}