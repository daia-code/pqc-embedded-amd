#include "randombytes.h"
#include "esp_random.h"

// Adăugăm atributul "weak" pentru a evita conflictul cu libsodium
__attribute__((weak)) 
int randombytes(uint8_t *out, size_t outlen) {
    esp_fill_random(out, outlen);
    return 0;
}