#ifndef SHA2_H
#define SHA2_H

#include <stddef.h>
#include <stdint.h>

// Contextul mbedtls pentru SHA512 este mai mare (~200 bytes). 256 e sigur.
typedef struct {
    uint8_t dummy[256]; 
} sha256ctx;

// Prototipuri pentru SPHINCS+
void sha256_inc_init(sha256ctx *ctx);
void sha256_inc_blocks(sha256ctx *ctx, const uint8_t *in, size_t inblocks);
void sha256_inc_finalize(uint8_t *out, sha256ctx *ctx, const uint8_t *in, size_t inlen);
void sha256_inc_ctx_clone(sha256ctx *out, const sha256ctx *in);
void sha256_inc_ctx_release(sha256ctx *ctx);

void sha256(uint8_t *out, const uint8_t *in, size_t inlen);
void sha512(uint8_t *out, const uint8_t *in, size_t inlen); // Adăugat pentru MGF1

#endif