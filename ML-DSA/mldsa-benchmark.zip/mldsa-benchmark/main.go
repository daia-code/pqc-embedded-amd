package main

import (
	"crypto/rand"
	"fmt"
	"math"
	"sort"
	"time"

	"github.com/cloudflare/circl/sign/dilithium"
)

const ROUNDS = 1000

type Stats struct {
	Median float64
	Min    float64
	Max    float64
	StdDev float64
}

func calculateStats(durations []float64) Stats {
	sort.Float64s(durations)
	min := durations[0]
	max := durations[len(durations)-1]
	median := durations[len(durations)/2]

	var sum, sumSq float64
	for _, d := range durations {
		sum += d
		sumSq += d * d
	}
	mean := sum / float64(len(durations))
	stdDev := math.Sqrt(math.Max(0, (sumSq/float64(len(durations)))-(mean*mean)))

	return Stats{Median: median, Min: min, Max: max, StdDev: stdDev}
}

// CORECTIE: am scos '*' de la dilithium.Mode
func runBenchmark(modeName string, mode dilithium.Mode) {
	keygenDurs := make([]float64, ROUNDS)
	signDurs := make([]float64, ROUNDS)
	verifyDurs := make([]float64, ROUNDS)

	msg := []byte("benchmark_disertatie_2026")

	for i := 0; i < ROUNDS; i++ {
		// KeyGen
		t0 := time.Now()
		pk, sk, _ := mode.GenerateKey(rand.Reader)
		keygenDurs[i] = float64(time.Since(t0).Microseconds()) / 1000.0

		// Sign
		t1 := time.Now()
		sig := mode.Sign(sk, msg)
		signDurs[i] = float64(time.Since(t1).Microseconds()) / 1000.0

		// Verify
		t2 := time.Now()
		_ = mode.Verify(pk, msg, sig)
		verifyDurs[i] = float64(time.Since(t2).Microseconds()) / 1000.0
	}

	fmt.Printf("\n--- %s ---\n", modeName)
	fmt.Printf("%-10s | %10s | %8s | %8s | %6s\n", "Operatiune", "Median(ms)", "Min(ms)", "Max(ms)", "σ(ms)")
	fmt.Println("------------------------------------------------------------")
	printRow("KeyGen", calculateStats(keygenDurs))
	printRow("Sign", calculateStats(signDurs))
	printRow("Verify", calculateStats(verifyDurs))
}

func printRow(op string, s Stats) {
	fmt.Printf("%-10s | %10.2f | %8.2f | %8.2f | %6.2f\n",
		op, s.Median, s.Min, s.Max, s.StdDev)
}

func main() {
	fmt.Println("Pornire Benchmark ML-DSA (1000 Iteratii)...")

	// Acum argumentele sunt trimise corect fara referinta (&) sau pointer (*)
	runBenchmark("ML-DSA-44", dilithium.Mode2)
	runBenchmark("ML-DSA-65", dilithium.Mode3)
	runBenchmark("ML-DSA-87", dilithium.Mode5)
}
