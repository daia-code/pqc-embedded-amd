module mldsa-stats

go 1.26.1

require github.com/cloudflare/circl v1.3.7

require golang.org/x/sys v0.15.0 // indirect
