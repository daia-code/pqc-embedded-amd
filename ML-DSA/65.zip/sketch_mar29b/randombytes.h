#ifndef RANDOMBYTES_H
#define RANDOMBYTES_H

#include <stdint.h>
#include <stddef.h>

#ifdef __cplusplus
extern "C" {
#endif

int randombytes(uint8_t *out, size_t outlen);
int PQCLEAN_randombytes(uint8_t *out, size_t outlen);

#ifdef __cplusplus
}
#endif

#endif