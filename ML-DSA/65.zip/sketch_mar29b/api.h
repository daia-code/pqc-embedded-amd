#ifndef PQCLEAN_MLDSA65_CLEAN_API_H
#define PQCLEAN_MLDSA65_CLEAN_API_H

#include <stddef.h>
#include <stdint.h>

// Definițiile trebuie să fie PRIMELE
#define PQCLEAN_MLDSA65_CLEAN_CRYPTO_PUBLICKEYBYTES 1952
#define PQCLEAN_MLDSA65_CLEAN_CRYPTO_SECRETKEYBYTES 4032
#define PQCLEAN_MLDSA65_CLEAN_CRYPTO_BYTES 3309
#define PQCLEAN_MLDSA65_CLEAN_CRYPTO_ALGNAME "ML-DSA-65"

#ifdef __cplusplus
extern "C" {
#endif

int PQCLEAN_MLDSA65_CLEAN_crypto_sign_keypair(uint8_t *pk, uint8_t *sk);

int PQCLEAN_MLDSA65_CLEAN_crypto_sign_signature(uint8_t *sig, size_t *siglen,
        const uint8_t *m, size_t mlen,
        const uint8_t *sk);

int PQCLEAN_MLDSA65_CLEAN_crypto_sign_verify(const uint8_t *sig, size_t siglen,
        const uint8_t *m, size_t mlen,
        const uint8_t *pk);

#ifdef __cplusplus
}
#endif

#endif