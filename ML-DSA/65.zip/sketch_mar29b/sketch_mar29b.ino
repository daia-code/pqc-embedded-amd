#include <Arduino.h>
#include <esp_system.h>
#include <math.h>
#include "api.h"
#include <esp_task_wdt.h>

#define PUBLICKEYBYTES  PQCLEAN_MLDSA65_CLEAN_CRYPTO_PUBLICKEYBYTES
#define SECRETKEYBYTES  PQCLEAN_MLDSA65_CLEAN_CRYPTO_SECRETKEYBYTES
#define SIGNATUREBYTES  PQCLEAN_MLDSA65_CLEAN_CRYPTO_BYTES

#define ROUNDS 1
#define CPU_FREQ_MHZ 240 // Frecventa standard ESP32

uint8_t *pk, *sk, *sig;
size_t siglen;
uint64_t keygen_t[ROUNDS], sign_t[ROUNDS], verify_t[ROUNDS];

static inline uint32_t cycles() {
    uint32_t c;
    asm volatile("rsr %0,ccount" : "=a"(c));
    return c;
}

// Conversie cicli -> microsecunde
double to_us(uint64_t c) {
    return (double)c / CPU_FREQ_MHZ;
}

// Functii statistice returnand microsecunde
double mean_us(uint64_t *a) {
    double s = 0;
    for (int i = 0; i < ROUNDS; i++) s += to_us(a[i]);
    return s / ROUNDS;
}

double min_us(uint64_t *a) {
    uint64_t m = a[0];
    for (int i = 1; i < ROUNDS; i++) if (a[i] < m) m = a[i];
    return to_us(m);
}

double max_us(uint64_t *a) {
    uint64_t m = a[0];
    for (int i = 1; i < ROUNDS; i++) if (a[i] > m) m = a[i];
    return to_us(m);
}

double stddev_us(uint64_t *a) {
    double m = mean_us(a), v = 0;
    for (int i = 0; i < ROUNDS; i++) {
        double d = to_us(a[i]) - m;
        v += d * d;
    }
    return sqrt(v / ROUNDS);
}

void benchmarkTask(void *pvParameters) {
    uint8_t msg[32] = "benchmark_pqc_2026";
    esp_task_wdt_delete(NULL); 

    for (int i = 0; i < ROUNDS; i++) {
        // KeyGen
        uint32_t t1 = cycles();
        PQCLEAN_MLDSA65_CLEAN_crypto_sign_keypair(pk, sk);
        keygen_t[i] = cycles() - t1;
        vTaskDelay(10 / portTICK_PERIOD_MS);

        // Sign
        uint32_t t3 = cycles();
        PQCLEAN_MLDSA65_CLEAN_crypto_sign_signature(sig, &siglen, msg, 32, sk);
        sign_t[i] = cycles() - t3;
        vTaskDelay(10 / portTICK_PERIOD_MS);

        // Verify
        uint32_t t5 = cycles();
        PQCLEAN_MLDSA65_CLEAN_crypto_sign_verify(sig, siglen, msg, 32, pk);
        verify_t[i] = cycles() - t5;
        
        vTaskDelay(50 / portTICK_PERIOD_MS);
    }

    // --- GENERARE TABEL ---
    Serial.println("\n--------------------------------------------------------------");
    Serial.println("                Media us | Minim us | Maxim us | Deviatie us");
    Serial.println("--------------------------------------------------------------");

    const char* labels[] = {"KeyGen", "Sign  ", "Verify"};
    uint64_t* data[] = {keygen_t, sign_t, verify_t};

    for(int i = 0; i < 3; i++) {
        Serial.printf("%s \t %.2f \t %.2f \t %.2f \t %.2f\n", 
                      labels[i], mean_us(data[i]), min_us(data[i]), max_us(data[i]), stddev_us(data[i]));
    }
    Serial.println("--------------------------------------------------------------");

    free(pk); free(sk); free(sig);
    vTaskDelete(NULL);
}

void setup() {
    Serial.begin(115200);
    pk = (uint8_t *)malloc(PUBLICKEYBYTES);
    sk = (uint8_t *)malloc(SECRETKEYBYTES);
    sig = (uint8_t *)malloc(SIGNATUREBYTES);
    xTaskCreatePinnedToCore(benchmarkTask, "bench", 102400, NULL, 1, NULL, 1);
}

void loop() {}
