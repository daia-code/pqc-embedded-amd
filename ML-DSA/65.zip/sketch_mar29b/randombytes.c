#include "randombytes.h"
#include <esp_random.h>
#include <string.h>

// Implementare simplificată pentru ESP32 pentru a evita assert-ul
int randombytes(uint8_t *out, size_t outlen) {
    if (out != NULL && outlen > 0) {
        esp_fill_random(out, outlen);
    }
    return 0;
}

// Alias pentru PQClean
int PQCLEAN_randombytes(uint8_t *out, size_t outlen) {
    return randombytes(out, outlen);
}