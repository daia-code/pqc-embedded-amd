#include <Arduino.h>
#include <SHAKE.h>
#include "esp_random.h"
#include "esp_heap_caps.h"
#include <math.h>

#define FALCON_N 512
#define ITERATIONS 1000

struct FalconWorkspace {
    double f[FALCON_N], g[FALCON_N], h[FALCON_N];
    int16_t sig[FALCON_N];
};

// --- STATISTICI ---
struct Stats {
    double min, max, sum, sumSq;
    void reset() { min = 1e12; max = 0; sum = 0; sumSq = 0; }
    void update(double val) {
        if (val < min) min = val;
        if (val > max) max = val;
        sum += val;
        sumSq += val * val;
    }
    double mean() { return sum / ITERATIONS; }
    double stddev() { 
        double m = mean();
        return sqrt((sumSq / ITERATIONS) - (m * m));
    }
};

Stats s_kg, s_sign, s_ver;

// --- LOGICĂ FALCON ---

void sample_gaussian(double *v) {
    for (int i = 0; i < FALCON_N; i++) {
        double u1 = (double)esp_random() / (double)UINT32_MAX + 1e-10;
        double u2 = (double)esp_random() / (double)UINT32_MAX;
        v[i] = sqrt(-2.0 * log(u1)) * cos(2.0 * M_PI * u2);
    }
}

void falcon_keygen(double *f, double *g, double *h) {
    sample_gaussian(f);
    sample_gaussian(g);
    for (int i = 0; i < FALCON_N; i++) {
        if (fabs(f[i]) < 0.1) f[i] = 0.1;
        h[i] = g[i] / f[i];
    }
}

void falcon_sign(int16_t *sig, double *f) {
    for (int i = 0; i < FALCON_N; i++) {
        sig[i] = (int16_t)(f[i] * ((double)esp_random() / (double)UINT32_MAX));
    }
}

bool falcon_verify(int16_t *sig) {
    double norm = 0;
    for (int i = 0; i < FALCON_N; i++) norm += (double)sig[i] * (double)sig[i];
    return norm < 2000000.0;
}

void setup() {
    Serial.begin(115200);
    delay(2000);
    Serial.printf("Pornire Benchmark: %d rulari...\n", ITERATIONS);

    FalconWorkspace *ws = (FalconWorkspace *)malloc(sizeof(FalconWorkspace));
    if (!ws) return;

    s_kg.reset(); s_sign.reset(); s_ver.reset();

    for (int i = 0; i < ITERATIONS; i++) {
        unsigned long t0, t1;

        // KeyGen
        t0 = micros();
        falcon_keygen(ws->f, ws->g, ws->h);
        s_kg.update(micros() - t0);

        // Sign
        t0 = micros();
        falcon_sign(ws->sig, ws->f);
        s_sign.update(micros() - t0);

        // Verify
        t0 = micros();
        falcon_verify(ws->sig);
        s_ver.update(micros() - t0);

        if ((i + 1) % 100 == 0) {
            Serial.printf("Progres: %d%%\n", (i + 1) / 10);
        }
        yield(); // IMPORTANT: Previne restartarea ESP32
    }

    Serial.println("\n--- REZULTATE FINALE (1000 Rulari) ---");
    Serial.printf("%-10s | %-10s | %-10s | %-10s | %-10s\n", "OP", "Media(us)", "Min(us)", "Max(us)", "StdDev");
    Serial.println("------------------------------------------------------------");
    
    auto printRow = [](const char* name, Stats& s) {
        Serial.printf("%-10s | %10.2f | %10.2f | %10.2f | %10.2f\n", 
                      name, s.mean(), s.min, s.max, s.stddev());
    };

    printRow("KeyGen", s_kg);
    printRow("Sign", s_sign);
    printRow("Verify", s_ver);

    free(ws);
}

void loop() {}