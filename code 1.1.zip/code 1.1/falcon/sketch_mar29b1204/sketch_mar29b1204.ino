#include <Arduino.h>
#include <SHAKE.h>
#include "esp_random.h"
#include "esp_heap_caps.h"
#include <math.h>

// --- PARAMETRII FALCON-1024 ---
#define FALCON_N 1024
#define ITERATIONS 1000

// Structură alocată în HEAP pentru a preveni Stack Overflow
// Un set complet ocupă aprox. 50 KB de RAM
struct Falcon1024Workspace {
    double f[FALCON_N];
    double g[FALCON_N];
    double h[FALCON_N];
    double tmp[FALCON_N]; // Buffer pentru FFT
    int16_t sig[FALCON_N];
};

struct Stats {
    double min, max, sum, sumSq;
    void reset() { min = 1e12; max = 0; sum = 0; sumSq = 0; }
    void update(double val) {
        if (val < min) min = val;
        if (val > max) max = val;
        sum += val;
        sumSq += val * val;
    }
    double mean() { return sum / ITERATIONS; }
    double stddev() { 
        double m = mean();
        double var = (sumSq / ITERATIONS) - (m * m);
        return sqrt(var > 0 ? var : 0);
    }
};

Stats s_kg, s_sign, s_ver;

// --- LOGICĂ MATEMATICĂ ---

void sample_gaussian_1024(double *v) {
    for (int i = 0; i < FALCON_N; i++) {
        double u1 = (double)esp_random() / (double)UINT32_MAX + 1e-10;
        double u2 = (double)esp_random() / (double)UINT32_MAX;
        v[i] = sqrt(-2.0 * log(u1)) * cos(2.0 * M_PI * u2);
    }
}

void falcon1024_keygen(double *f, double *g, double *h) {
    sample_gaussian_1024(f);
    sample_gaussian_1024(g);
    for (int i = 0; i < FALCON_N; i++) {
        if (fabs(f[i]) < 0.1) f[i] = 0.1;
        h[i] = g[i] / f[i]; // Simulare NTRU h = g/f
    }
}

void falcon1024_sign(int16_t *sig, double *f) {
    for (int i = 0; i < FALCON_N; i++) {
        // Semnătura include hash-ul mesajului (simulat aici prin PRNG hardware)
        sig[i] = (int16_t)(f[i] * ((double)esp_random() / (double)UINT32_MAX) * 1.5);
    }
}

bool falcon1024_verify(int16_t *sig) {
    double norm = 0;
    for (int i = 0; i < FALCON_N; i++) {
        norm += (double)sig[i] * (double)sig[i];
    }
    // Pragul de normă pentru N=1024 este mai mare decât la N=512
    return norm < 4000000.0;
}

// --- BENCHMARK ---

void setup() {
    Serial.begin(115200);
    delay(2000);
    Serial.printf("\n--- BENCHMARK FALCON-1024 (NIST LEVEL 5) ---\n");
    Serial.printf("Rulări planificate: %d\n", ITERATIONS);

    // Alocare dinamică (MALLOC_CAP_8BIT pentru RAM internă rapidă)
    Falcon1024Workspace *ws = (Falcon1024Workspace *)heap_caps_malloc(sizeof(Falcon1024Workspace), MALLOC_CAP_8BIT);
    
    if (ws == NULL) {
        Serial.println("EROARE: Memorie insuficientă pentru N=1024!");
        return;
    }

    s_kg.reset(); s_sign.reset(); s_ver.reset();

    for (int i = 0; i < ITERATIONS; i++) {
        unsigned long t0;

        // KeyGen
        t0 = micros();
        falcon1024_keygen(ws->f, ws->g, ws->h);
        s_kg.update(micros() - t0);

        // Sign
        t0 = micros();
        falcon1024_sign(ws->sig, ws->f);
        s_sign.update(micros() - t0);

        // Verify
        t0 = micros();
        falcon1024_verify(ws->sig);
        s_ver.update(micros() - t0);

        if ((i + 1) % 100 == 0) {
            Serial.printf("Progres: %d%%\n", (i + 1) / 10);
        }
        yield(); // Previne declanșarea Task Watchdog
    }

    Serial.println("\n--- REZULTATE FINALE FALCON-1024 ---");
    Serial.printf("%-10s | %-12s | %-12s | %-12s | %-10s\n", "OP", "Media(ms)", "Min(ms)", "Max(ms)", "StdDev(us)");
    Serial.println("----------------------------------------------------------------------");
    
    auto printRow = [](const char* name, Stats& s) {
        // Afișăm în ms pentru claritate, StdDev în us
        Serial.printf("%-10s | %12.3f | %12.3f | %12.3f | %10.2f\n", 
                      name, s.mean()/1000.0, s.min/1000.0, s.max/1000.0, s.stddev());
    };

    printRow("KeyGen", s_kg);
    printRow("Sign", s_sign);
    printRow("Verify", s_ver);

    Serial.printf("\nRAM liberă finală: %u bytes\n", esp_get_free_heap_size());

    heap_caps_free(ws);
}

void loop() {}