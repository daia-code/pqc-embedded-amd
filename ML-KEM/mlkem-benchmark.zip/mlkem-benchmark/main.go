package main

import (
	"fmt"
	"math"
	"time"

	"github.com/cloudflare/circl/kem"
	"github.com/cloudflare/circl/kem/mlkem/mlkem512"
	"github.com/cloudflare/circl/kem/mlkem/mlkem768"
	"github.com/cloudflare/circl/kem/mlkem/mlkem1024"
)

const ITER = 1000

type Stats struct {
	mean float64
	min  float64
	max  float64
	std  float64
}

func computeStats(v []float64) Stats {
	sum := 0.0
	min := v[0]
	max := v[0]

	for _, x := range v {
		sum += x
		if x < min {
			min = x
		}
		if x > max {
			max = x
		}
	}

	mean := sum / float64(len(v))

	var variance float64
	for _, x := range v {
		variance += (x - mean) * (x - mean)
	}
	variance /= float64(len(v))

	return Stats{mean, min, max, math.Sqrt(variance)}
}

func bench(name string, s kem.Scheme) {

	keygen := make([]float64, ITER)
	encaps := make([]float64, ITER)
	decaps := make([]float64, ITER)

	var pk kem.PublicKey
	var sk kem.PrivateKey
	var ct, ss1, ss2 []byte

	for i := 0; i < ITER; i++ {

		// KEYGEN (fără rand.Reader!)
		start := time.Now()
		pk, sk, _ = s.GenerateKeyPair()
		keygen[i] = float64(time.Since(start).Microseconds())

		// ENCAPS
		start = time.Now()
		ct, ss1, _ = s.Encapsulate(pk)
		encaps[i] = float64(time.Since(start).Microseconds())

		// DECAPS
		start = time.Now()
		ss2, _ = s.Decapsulate(sk, ct)
		decaps[i] = float64(time.Since(start).Microseconds())

		if string(ss1) != string(ss2) {
			panic("mismatch")
		}
	}

	k := computeStats(keygen)
	e := computeStats(encaps)
	d := computeStats(decaps)

	fmt.Printf("\n=== %s ===\n", name)
	fmt.Println("Operație\tμ\tMin\tMax\tσ")

	fmt.Printf("KeyGen\t%.2f\t%.0f\t%.0f\t%.2f\n",
		k.mean, k.min, k.max, k.std)

	fmt.Printf("Encaps\t%.2f\t%.0f\t%.0f\t%.2f\n",
		e.mean, e.min, e.max, e.std)

	fmt.Printf("Decaps\t%.2f\t%.0f\t%.0f\t%.2f\n",
		d.mean, d.min, d.max, d.std)
}

func main() {

	fmt.Println("ML-KEM Benchmark")

	bench("ML-KEM-512", mlkem512.Scheme())
	bench("ML-KEM-768", mlkem768.Scheme())
	bench("ML-KEM-1024", mlkem1024.Scheme())
}